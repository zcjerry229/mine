#! /usr/bin/env bash
$XGETTEXT *.cpp -o $podir/kdiff3fileitemactionplugin.pot
